
public class NodoG {
    
   char valor;
   NodoLiga ini, fin;
   
   public NodoG(char v){
       valor=v;
       ini=null;
       fin=null;
   }

    NodoG() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
   public boolean insertarLiga(NodoG direccion){
       NodoLiga temp = new NodoLiga(direccion);
       
       if(temp==null){
           return false;
       }
       if(ini==null && fin==null){
           ini=fin=temp;
           return true;
       }
       fin.sig=temp;
       temp.ant=fin;
       fin=temp;
       return true;
   }
   
   public boolean eliminarLiga(NodoG direccion){
       if(ini==null && fin==null){
           return false;
       }
       if(ini==fin && ini.direccion==direccion){
           fin=ini=null;
           return true;
       }
       if(ini.direccion==direccion){
           NodoLiga temp=ini.sig;
           ini.sig=null;
           temp.ant=null;
           ini=temp;
           return true;
       }
       if(fin.direccion==direccion){
           NodoLiga temp=fin.ant;
           temp.sig=null;
           temp.ant=null;
           fin=temp;
           return true;
       }
       NodoLiga temp=ini.sig;
       do{
           if(temp.direccion==direccion){
               temp.ant.sig=temp.sig;
               temp.sig.ant=temp.ant;
               temp.sig=temp.ant=null;
               return true;
           }
           temp=temp.sig;
       }while(temp!=fin);
       return false;
   }
   
   public boolean esHoja(){
       return ini==null && fin==null;
   }
   
   public String mostrar(){
        if(ini==null && fin==null){
            return "ARBOL VACIO";
        }
        return mostrar(ini);
    }
    
    private String mostrar(NodoLiga temp){
        if(temp==null){
            return "";
        }
        return temp.direccion+"\n"+mostrar(temp.sig);
    }
    
}
