/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 52311
 */
public class ArbolGeneral {
    NodoG raiz;
    
    public ArbolGeneral(){
        raiz=null;
    }
    private NodoG buscarNodo(String path){
        if(path.isEmpty()){
            return null;
        }
        path=path.substring(1);
        String[] vector=path.split("/");
        
        if(raiz.valor==vector[0].charAt(0)){
            for(NodoLiga temp=raiz.ini;temp!=null;temp=temp.sig){
                if(temp.direccion.valor==vector[1].charAt(0)){
                    if(vector.length==2){
                        return temp.direccion;
                    }
                    return buscarNodo(temp.direccion, path.substring(3));
                }
            }
        }
        return null;
    }
    private NodoG buscarNodo(NodoG nodoEncontrado, String path){
        if(path.isEmpty()){
            return nodoEncontrado;
        }
        path=path.substring(1);
        String vector[];
        if(path.length()==1){
            vector=new String[1];
            vector[0]=path;
        }else{
            vector=path.split("/");
        }
        for(NodoLiga temp=nodoEncontrado.ini; temp!=null; temp=temp.sig){
            if(temp.direccion.valor==vector[0].charAt(0)){
                buscarNodo(temp.direccion, path.substring(1));
            }
        }
        return null;
    }
    
    public boolean insertarNodoGeneral(String path,char valor){
        if(path.isEmpty()){
            if(raiz==null){
                raiz = new NodoG(valor);
                return true;
            }
            return false;
        }
        NodoG padre=buscarNodo(path);
        if(padre==null){
            return false;
        }
        NodoG buscarhijo=buscarNodo(path+"/"+valor);
        if(buscarhijo!=null){
            return false;
        }
        buscarhijo=null;
        
        NodoG hijo=new NodoG(valor);
        if(hijo==null){
            return false;
        }
        return padre.insertarLiga(hijo);
    }
    
    public boolean eliminarNodoGeneral(String path){
        NodoG hijo=buscarNodo(path);
        if(hijo==null){
            return false;
        }
        if(hijo==raiz){
            if(raiz.esHoja()){
                raiz=null;
                return true;
            }
            return false;
        }
        String pathPadre=obtenerPathPadre(path);
        
        NodoG padre=buscarNodo(pathPadre);
        if(padre==null){
            return false;
        }
        if(hijo.esHoja()){
            return padre.eliminarLiga(hijo);
        }
        return false;
    }
    
    private String obtenerPathPadre(String pathHijo){
        int posicionUltimaDiagonal=pathHijo.lastIndexOf("/")-1;
        return pathHijo.substring(0, posicionUltimaDiagonal);
    }
    
    
  
}
