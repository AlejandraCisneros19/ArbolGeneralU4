
public class NodoLiga {
    
    NodoG direccion;
    NodoLiga sig,ant;
    
    public NodoLiga(NodoG direccion){
        this.direccion=direccion;
        sig=ant=null;
    }
    
}
